<?php
/**
 * Created by PhpStorm.
 * User: patrick
 * Date: 2017-11-23
 * Time: 19:32
 */




include './common/header.php';
?>
<div class="container">
    <h1>Welcome to Algonquin College Album Management Website</h1>

    <p>You can upload your pictures <a href="UploadPicture.php">here</a>.</p>

    <p>You can view your pictures <a href="MyPictures.php">here</a>.</p>
</div>
<?php
include './common/footer.php';
?>